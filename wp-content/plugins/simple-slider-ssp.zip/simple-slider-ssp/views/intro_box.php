<div id="ssp-col-right" class="hidden">
		
	<div class="wp-box">
		<div class="inner">
			<h3 class="h2"><?php _e("WordPress Slider Plugin",'ssp'); ?></h3>
		
			<h2><?php _e("Support",'ssp'); ?></h3>
			<p>Please post your question on 
				<a href="http://muneeb.me/support/forum/wordpress-slider-plugin-2/">
					support forum
				</a>
			</p>
					
			<h2><?php _e("Premium Version",'ssp'); ?></h3>
			<p><?php _e("For more advanced features, skins and to get guaranteed support be sure to check out premium version of the plugin.",'ssp'); ?><br />
			<a href="http://muneeb.me/wordpress-slider-plugin/" target="_blank"><?php _e("Visit the Premium Version website",'ssp'); ?></a></p>
		
			</div>
			<div class="footer footer-blue">
				<ul class="left hl">
					<li><?php _e("Created by",'ssp'); ?> Muneeb ur Rehman</li>
				</ul>
				<ul class="right hl">
					<li><a href="http://twitter.com/tmuneeb"><?php _e("Follow",'ssp'); ?></a></li>
				</ul>
			</div>
	</div>
</div>